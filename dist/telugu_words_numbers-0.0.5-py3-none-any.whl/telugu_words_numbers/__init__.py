from telugu_words_numbers.telugu_word_to_number import TeluguWordsToNumber

__all__= [
    "TeluguWordsToNumber"
    ]